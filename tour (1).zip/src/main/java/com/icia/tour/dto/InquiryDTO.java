package com.icia.tour.dto;

import lombok.Data;

@Data
public class InquiryDTO {
  private int INum;
  private String IName;
  private String IContents;
  private String IMail;
  private int ICheck;
}

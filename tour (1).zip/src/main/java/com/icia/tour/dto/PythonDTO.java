package com.icia.tour.dto;

import lombok.Data;

@Data
public class PythonDTO {
	private String course_explain;
	private String course_img;
	private String course_title;
	private String course_addr;
	private String addr;
	private String img1;
	private String img2;
	private String img3;
}
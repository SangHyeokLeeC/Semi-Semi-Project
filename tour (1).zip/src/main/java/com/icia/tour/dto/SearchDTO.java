package com.icia.tour.dto;

import lombok.Data;

@Data
public class SearchDTO {
	private String category;
	private String keyword;
}
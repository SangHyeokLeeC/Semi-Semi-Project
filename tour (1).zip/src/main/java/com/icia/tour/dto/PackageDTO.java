package com.icia.tour.dto;

import lombok.Data;

@Data
public class PackageDTO {
	private int pnum;
	private String pname;
	private int pscope;
	private int phit;
	private String pcountry;
	private String pexplain;
	private String pimage;
	private String pi1;
	private String pi2;
	private String pi3;
}